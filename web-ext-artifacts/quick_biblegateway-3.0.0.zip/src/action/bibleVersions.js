const customTranslations = [ "KJ21", "ASV", "AMP", "AMPC", "BRG", "CSB", "CEB", "CJB", "CEV", "DARBY", "DLNT", "DRA",
"ERV", "EHV", "ESVUK", "EXB", "GNV", "GW", "GNT", "HCSB","ICB", "ISV", "PHILLIPS", "JUB", "AKJV", "LEB", "TLB",
"MSG", "MEV", "MOUNCE", "NOG", "NABRE", "NASB", "NASB1995", "NCB", "NCV", "NIRV", "NIVUK", "NLV", "NLT", "NMB",
"NRSV", "NRSVA", "NRSVACE", "NRSVCE", "NTE", "OJB", "TPT", "RGT", "RSV", "RSVCE", "TLV", "VOICE", "WEB", "WE","WYC","YLT" ];

const dropwDownTranslations = ['NIV','NET','KJV','NKJV','ESV'];