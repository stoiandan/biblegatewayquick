/*
    Contains a list of accepted communication messages
*/


const GET_VERSION = 'getVersion';

const SET_VERSION = 'setVersion';